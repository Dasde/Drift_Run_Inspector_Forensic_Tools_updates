local pu = {}
local offsetY = 0
local paints = table.new(0, 0)
local function getCarPaint(carIndex)
    if not paints[carIndex] then
        paints[carIndex] = ac.TrackPaint()
        paints[carIndex].castStep = math.huge
        paints[carIndex].ageFactor = 0.1
        --paints[carIndex].forceRecast = true
        paints[carIndex].alignShapes = false
    end
    return paints[carIndex]
end

local contactPointsData = table.new(0, 0)

function pu:resetPaints()
    for i, paint in pairs(paints) do
        if paint then
            paint:reset()
            paint:release()
        end
    end
    paints = table.new(0, 0)
end

function pu:resetContactPointsData()
    table.clear(contactPointsData)
    --contactPointsData = table.new(0, 0)
end

function pu:resetCarContactPointsData(carIndex)
    local car = ac.getCar(carIndex)
    contactPointsData[carIndex] = {
        lastAngle = 0,
        FL = vec3(car.wheels[0].contactPoint.x, car.wheels[0].contactPoint.y + offsetY, car.wheels[0].contactPoint.z),
        FR = vec3(car.wheels[1].contactPoint.x, car.wheels[1].contactPoint.y + offsetY, car.wheels[1].contactPoint.z),
        RL = vec3(car.wheels[2].contactPoint.x, car.wheels[2].contactPoint.y + offsetY, car.wheels[2].contactPoint.z),
        RR = vec3(car.wheels[3].contactPoint.x, car.wheels[3].contactPoint.y + offsetY, car.wheels[3].contactPoint.z),
    }
end

-- local function getIntersectionPoint(_A, _B, _C, _D)
--     local I = vec2(_B.x - _A.x, _B.y - _A.y)
--     local J = vec2(_D.x - _C.x, _D.y - _C.y)
--     local m = 0
--     local k =0
--     local diviseur = I.x * J.y - I.y * J.x
--     if (diviseur ~= 0) then
--         m = (I.x * _A.y
--              - I.x * _C.y
--              - I.y * _A.x
--              + I.y * _C.x
--             ) / diviseur
--         k = (J.x * _A.y
--              - J.x * _C.y
--              - J.y * _A.x
--              + J.y * _C.x
--             ) / diviseur
--     end
--     if (diviseur == 0 or (m <= 0 or m>=1) or (k <= 0 or k>=1) ) then return nil end
--     return vec2(_C.x + m * J.x, _C.y + m * J.y)
-- end

local function getCarContactPointsData(carIndex)
    if not contactPointsData[carIndex] then
        local car = ac.getCar(carIndex)
        contactPointsData[carIndex] = {
            lastAngle = 0,
            FL = vec3(car.wheels[0].contactPoint.x, car.wheels[0].contactPoint.y + offsetY, car.wheels[0].contactPoint.z),
            FR = vec3(car.wheels[1].contactPoint.x, car.wheels[1].contactPoint.y + offsetY, car.wheels[1].contactPoint.z),
            RL = vec3(car.wheels[2].contactPoint.x, car.wheels[2].contactPoint.y + offsetY, car.wheels[2].contactPoint.z),
            RR = vec3(car.wheels[3].contactPoint.x, car.wheels[3].contactPoint.y + offsetY, car.wheels[3].contactPoint.z),
        }
    end
    return contactPointsData[carIndex]
end

local function updateCarContactPointsData(carIndex, angle)
    local car = ac.getCar(carIndex)
    contactPointsData[carIndex] = {
        FL = vec3(car.wheels[0].contactPoint.x, car.wheels[0].contactPoint.y + offsetY, car.wheels[0].contactPoint.z),
        FR = vec3(car.wheels[1].contactPoint.x, car.wheels[1].contactPoint.y + offsetY, car.wheels[1].contactPoint.z),
        RL = vec3(car.wheels[2].contactPoint.x, car.wheels[2].contactPoint.y + offsetY, car.wheels[2].contactPoint.z),
        RR = vec3(car.wheels[3].contactPoint.x, car.wheels[3].contactPoint.y + offsetY, car.wheels[3].contactPoint.z),
        lastAngle = angle
    }
end

local function raphPoint(point)
    return vec3(point.x, point.y + offsetY, point.z)
end

local function vec3equals(p1, p2)
    return p1.x == p2.x and p1.y == p2.y and p1.z == p2.z
end

local function testEquals(p1, p2, p3)
    return (vec3equals(p1, p2) or vec3equals(p1, p3) or vec3equals(p2, p3))
end

function pu:drawCarContactPoints(car, color, driftAngleWithDirection)
    if car and car.wheels then
        local paint = getCarPaint(car.index)
        local carContactPointsData = getCarContactPointsData(car.index)
        local angleWithDirection = driftAngleWithDirection

        if not testEquals(car.wheels[0].contactPoint, carContactPointsData.FL, car.wheels[3].contactPoint) then
            paint:to(car.wheels[0].contactPoint)
            paint:to(car.wheels[3].contactPoint)
            paint:to(carContactPointsData.FL)
            paint:fill(color)
        else
            ac.log('equals 1 !!!!!')
        end

        if not testEquals(car.wheels[0].contactPoint, carContactPointsData.RR, car.wheels[3].contactPoint) then
            paint:to(car.wheels[0].contactPoint)
            paint:to(carContactPointsData.RR)
            paint:to(car.wheels[3].contactPoint)
            paint:fill(color)
        else
            ac.log('equals 2 !!!!!')
        end

        if not testEquals(car.wheels[0].contactPoint, carContactPointsData.FL, carContactPointsData.RR) then
            paint:to(car.wheels[0].contactPoint)
            paint:to(carContactPointsData.FL)
            paint:to(carContactPointsData.RR)
            paint:fill(color)
        else
            ac.log('equals 3 !!!!!')
        end

        if not testEquals(carContactPointsData.RR, carContactPointsData.FL, car.wheels[3].contactPoint) then
            paint:to(car.wheels[3].contactPoint)
            paint:to(carContactPointsData.FL)
            paint:to(carContactPointsData.RR)
            paint:fill(color)
        else
            ac.log('equals 4 !!!!!')
        end
        if not testEquals(car.wheels[1].contactPoint, carContactPointsData.FR, carContactPointsData.RL) then
            paint:to(car.wheels[1].contactPoint)
            paint:to(carContactPointsData.FR)
            paint:to(carContactPointsData.RL)
            paint:fill(color)
        else
            ac.log('equals 5 !!!!!')
        end
        if not testEquals(car.wheels[2].contactPoint, carContactPointsData.FR, carContactPointsData.RL) then
            paint:to(car.wheels[2].contactPoint)
            paint:to(carContactPointsData.FR)
            paint:to(carContactPointsData.RL)
            paint:fill(color)
        else
            ac.log('equals 6 !!!!!')
        end
        if not testEquals(car.wheels[1].contactPoint, carContactPointsData.FR, car.wheels[2].contactPoint) then
            paint:to(car.wheels[1].contactPoint)
            paint:to(car.wheels[2].contactPoint)
            paint:to(carContactPointsData.FR)
            paint:fill(color)
        else
            ac.log('equals 7 !!!!!')
        end
        if not testEquals(car.wheels[1].contactPoint, carContactPointsData.RL, car.wheels[2].contactPoint) then
            paint:to(car.wheels[1].contactPoint)
            paint:to(carContactPointsData.RL)
            paint:to(car.wheels[2].contactPoint)
            paint:fill(color)
        else
            ac.log('equals 8 !!!!!')
        end
        updateCarContactPointsData(car.index, angleWithDirection)
    end
end

return pu
