local updateUtils = {}

local updatingApp = false
local repoVersion ="0.0.0"
local appVersion
local changelog =""
local _appName
local _urlRelease
local _urlManifest

local AppSettings = ac.storage {
	autoUpdate = true
}

function updateUtils.init(appName, urlManifest, urlRelease)
	_appName = appName
	_urlRelease = urlRelease
	_urlManifest = urlManifest
	local manifest = ac.INIConfig.load(ac.dirname() .. '/manifest.ini', ac.INIFormat.Extended)
	appVersion = manifest:get('ABOUT', 'VERSION', "0.0.0")
end
function updateUtils.isUpdatingApp()
    return updatingApp
end

---Write a file on disk
---@param file string relative path of the file
---@param content string content of the file
---@param folder string destinatin folder
local function writeFile(file, content, folder)
	local filename = folder .. "\\" .. file -- :match("/(.*)")
	filename = filename:replace("/", "\\")
	if not io.dirExists(filename) then
		io.createFileDir(filename)
	end
	-- print(filename)
	if io.save(filename, content) then
		-- print(filename .. " successfully written to disk")
	else
		print("Error writing " .. filename)
	end
end

---Update the app to a specific version
---@param version string
local function updateApp(version)
	updatingApp = true
	---@diagnostic disable-next-line: inject-field
	ac.storage.updateToVersion = version
	web.get(_urlRelease, function(errRelease, responseRelease)
		if errRelease then
			updatingApp = false
			print(errRelease)
			error(errRelease)
			return
		end
		local acFolder = ac.getFolder(ac.FolderID.Root)
		local appFile, appContent
		for _, file in ipairs(io.scanZip(responseRelease.body)) do
			local content = io.loadFromZip(responseRelease.body, file)
			if content then
				if (file:endsWith(_appName .. ".lua")) then
					appFile = file
					appContent = content
				else
					writeFile(file, content, acFolder)
				end
			end
		end
		if appContent then
			writeFile(appFile, appContent, acFolder)
		end
	end)
	updatingApp = false
end

---Get the latest version from the repo and update if asked.
---@param update boolean
---@param force? boolean
local function getLatestVersion(update, force)
	web.get(_urlManifest, function(err, response)
		if err then 
			print(error(err)) 
			return
		end
		local repoManifest = response.body
		if not repoManifest then return print('Missing manifest on the repo.') end
		repoVersion = ac.INIConfig.parse(repoManifest, ac.INIFormat.Extended):get('ABOUT', 'VERSION', "0.0.0")
		changelog = ac.INIConfig.parse(repoManifest, ac.INIFormat.Extended):get('ABOUT', 'CHANGELOG', "")
		if (update) then
			if repoVersion:versionCompare(appVersion) <= 0 then
				print("no update. versions : repo " .. repoVersion .. " app " .. appVersion)
				if (not force) then return end
			end
			updateApp(repoVersion)
		end
	end)
end

function updateUtils.checkForUpdate()
	if ac.storage.updateToVersion and ac.storage.updateToVersion:versionCompare(appVersion) == 0 then
		print("App successfully updated to version " .. appVersion)
		---@diagnostic disable-next-line: inject-field
		ac.storage.updateToVersion = "0.0.0"
	end
	getLatestVersion(AppSettings.autoUpdate)
end

function updateUtils.drawUI()
	ui.text("Version " .. appVersion)
	if repoVersion:versionCompare(appVersion) > 0 then
		if not AppSettings.autoUpdate then
			ui.textColored("A new version (" .. repoVersion .. ") is available", rgbm.colors.red)
			if ui.button("Update...") then
				updateApp(repoVersion)
			end
		end
	else
		ui.textColored("The latest version is installed.", rgbm.colors.green)
		if ui.button("Reset app..", ui.ButtonFlags.Confirm) then
			getLatestVersion(true, true)
		end
	end
	if ui.checkbox("Auto-Update", AppSettings.autoUpdate) then
		AppSettings.autoUpdate = not AppSettings.autoUpdate
	end
	ui.setNextTextBold()
	ui.text("Changelog")
	for index, line in ipairs(changelog:split("\n")) do
		ui.text(line)
	end
end

return updateUtils