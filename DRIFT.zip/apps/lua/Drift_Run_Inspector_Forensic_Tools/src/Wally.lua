local wu = {}
local meshes = table.new(32, 0)

---Get the wally mesh for the car index
---@param index integer
---@return ac.SceneReference
local function getMesh(index)
    return meshes[index]
end

---Remove the wally from the top of the car
---@param car ac.StateCar
function wu:removeWally(car)
    local mesh = meshes[car.index]
    if (mesh) then
        mesh:dispose()
        mesh = nil
        meshes[car.index] = nil
    end
end

---Display a wally on top of the car
---@param car ac.StateCar
function wu:displayWally(car)
    local mesh = meshes[car.index]
    if (mesh) then
        mesh:dispose()
    end
    local rootNode = ac.findNodes('carRoot:' .. car.index):findNodes('BODYTR')
    mesh = rootNode:loadKN5(ac.dirname() .. "/assets/racedatalabs-wally.kn5")
    local rayWorldPositionStart = car.bodyTransform:transformPoint(vec3(0,3,-0.4))
    local rayWorldPositionEnd = car.bodyTransform:transformPoint(vec3(0,2,-0.4))

    local ray = render.createRay(rayWorldPositionStart,rayWorldPositionEnd - rayWorldPositionStart)
    local distCar = ray:cars()
    mesh:setPosition(vec3(0, 3 - distCar, -0.4))
    meshes[car.index] = mesh
end

return wu
