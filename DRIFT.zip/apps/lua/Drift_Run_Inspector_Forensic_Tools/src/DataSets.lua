require 'src/GraphUtils'

local function round2(value)
    return math.floor(value * 100) / 100 -- Round to 2 decimal places
end

DataSet = class('DataSet')
function DataSet:initialize(title, minValue, maxValue)
    ---@public
    self.title = title
    self.data = table.new(20, 0)
    self.stats = table.new(20, 0)
    self.minValueGraph = minValue or 0
    self.maxValueGraph = maxValue or 100
end

function DataSet:addValue(value, index, sizeLimit, debug)
    local car = ac.getCar(index)
    local name = car:driverName()
    if debug then
        ac.debug(name .. " " .. self.title .. " ", value, self.minValueGraph, self.maxValueGraph, 5,
            ac.DebugCollectMode.Maximum)
    end
    if not self.data[index] then
        self.data[index] = table.new(100, 5) -- Initialize the data table if it doesn't exist
    end
    table.insert(self.data[index], 0, value)
    if #self.data[index] > sizeLimit then
        table.remove(self.data[index])
    end
    local statsValue = round2(value) -- Round to 2 decimal places
    if not self.stats[index] then
        self.stats[index] = { minValue = statsValue, maxValue = statsValue }
    end
    if not self.stats[index].minValue or statsValue < self.stats[index].minValue then
        self.stats[index].minValue = statsValue
    end
    if not self.stats[index].maxValue or statsValue > self.stats[index].maxValue then
        self.stats[index].maxValue = statsValue
    end
end

function DataSet:getLastValue(index)
    return self.data[index][0]
end

function DataSet:drawGraph(x, y, width, height, index, color, drawGraphLines)
    if not self.data[index] or #self.data[index] == 0 then
        return
    end
    ui.drawGraph(x, y, width, height, self.data[index], color, self.title, self.minValueGraph, self.maxValueGraph,
        drawGraphLines)
end

function DataSet:__tostring()
    return string.format("DataSet(title=%s, minValue=%s, maxValue=%s, dataSize=%d)", self.title, self.minValueGraph,
        self.maxValueGraph, #self.data)
end

function DataSet:displayStats(index)
    if not self.stats[index] or not self.data[index] then
        return string.format("%s : No data available", self.title)
    end
    return string.format("%s : %s - min=%s, max=%s", self.title, round2(self.data[index][0]),
        round2(self.stats[index].minValue), round2(self.stats[index].maxValue))
end

function DataSet:resetStats(index)
    self.stats[index] = { minValue = 0, maxValue = 0 }
end

Stats = class('Stats')
function Stats:initialize()
    ---@public
    self.collisions = 0
    self.collisionsWithWalls = 0
    self.collisionsWithCars = 0
    self.lastCollision = 0
    self.lastCollisionsWithWalls = 0
    self.lastCollisionsWithCars = 0
    self.lastCollisionWith = ""
    self.wheelsOustide = 0
    self.lastWheelsOutside = 0
end

DataSets = class('DataSets')
function DataSets:initialize()
    ---@public
    self.speed = DataSet("Speed", 0, 250)
    self.speedDiff = DataSet("Speed Diff", -150, 150)
    self.driftAngle = DataSet("Drift Angle", 0, 130)
    self.driftAngleWithDirection = DataSet("Drift Angle With Direction", 0, 130)
    self.gforces = DataSet("G-Forces", -2.5, 2.5)
    self.throttle = DataSet("Throttle", 0, 1)
    self.clutch = DataSet("Clutch", 0, 1)
    self.brake = DataSet("Brake", 0, 1)
    self.handbrake = DataSet("Handbrake", 0, 1)
    self.gear = DataSet("Gear", 0, 6)
    self.stats = DataSet("Stats", 0, 100)
end

function DataSets:drawGraphs(x, y, width, height, index, color, drawGraphLines, dataSets)
    local j = 1
    for i, dataSet in ipairs(self:keySet()) do
        if table.contains(dataSets, dataSet) and self[dataSet] and self[dataSet].drawGraph then
            self[dataSet]:drawGraph(x, y + (j - 1) * height, width, height, index, color, drawGraphLines)
            j = j + 1
        end
    end
end

function DataSets:__tostring()
    return string.format(
        "DataSets(speed=%s, speedDiff=%s, driftAngle=%s, gforces=%s, throttle=%s, clutch=%s, brake=%s, handbrake=%s, gear=%s)",
        self.speed.title, self.speedsDiff.title, self.driftAngle.title, self.gforces.title,
        self.throttle.title, self.clutch.title, self.brake.title, self.handbrake.title, self.gear.title)
end

function DataSets:keySet()
    return {
        "driftAngle",
        "speed",
        "speedDiff",
        "gforces",
        "throttle",
        "clutch",
        "brake",
        "handbrake",
        "gear"
    }
end

function DataSets:updateStatsValue(value, field, index)
    if not self.stats[index] then
        self.stats[index] = Stats() -- Initialize the data table if it doesn't exist
    end
    self.stats[index][field] = value
end

function DataSets:displayStats(index)
    local statsDisplay = {}
    for i, dataSet in ipairs(self:keySet()) do
        if self[dataSet] and self[dataSet].displayStats then
            table.insert(statsDisplay, self[dataSet]:displayStats(index))
        end
    end
    return table.concat(statsDisplay, "\n")
end

function DataSets:resetStats(index)
    for i, dataSet in ipairs(self:keySet()) do
        if self[dataSet] and self[dataSet].resetStats then
            self[dataSet]:resetStats(index)
        end
    end
    self.stats[index] = Stats()
end

function DataSets:exportStats(index)
    local statsSave = {}
    statsSave.time=os.clock()  -- string.format("'time':%.2f",os.clock()))
    for i, dataSet in ipairs(self:keySet()) do
        if self[dataSet]  then
            statsSave[dataSet] = string.format("%.2f",self[dataSet]:getLastValue(index))
            --table.insert(statsSave, stringify(string.format("%s:%.2f",dataSet,self[dataSet]:getLastValue(index))))
        end
    end
    statsSave.tiresOut = self.stats[index].lastWheelsOutside
    statsSave.lastCollision = self.stats[index].lastCollision
    statsSave.lastCollisionsWithWalls = self.stats[index].lastCollisionsWithWalls
    statsSave.lastCollisionsWithCars = self.stats[index].lastCollisionsWithCars
    statsSave.lastCollisionWith = self.stats[index].lastCollisionWith
    return JSON.stringify(statsSave)
end

function DataSets:resetCollisionsStats(index)
    self.stats[index].lastCollision = 0
    self.stats[index].lastCollisionsWithWalls = 0
    self.stats[index].lastCollisionsWithCars = 0
    self.stats[index].lastCollisionWith = ""
end

---Save the stats on disk
---@param index integer
---@param filename string
function DataSets:saveStats(index, filename)
    local statsText = self:exportStats(index)
    local filenameForIndex = filename:replace("###", string.format("%d",index))
    --local statsText = table.concat(statsDisplay, "\n")
    -- local folder = ac.getFolder(ac.FolderID.Documents) .. "/DRIFT Stats"
    -- if not io.fileExists(folder) then
    --     io.createDir(folder)
    -- end
    -- local filename = folder .. "/".. ac.getTrackName() .. "-" .. index .. "-" .. string.format("%s",ac.getSim().timestamp) .. ".json"
    if io.fileExists(filenameForIndex) then
        local file = io.open(filenameForIndex, "a+")
        file:setvbuf("no")
        if (file) then
            statsText = "," .. statsText
            file:write(statsText)
            file:close()
        end
    else
        io.save(filenameForIndex, statsText)
    end
end
