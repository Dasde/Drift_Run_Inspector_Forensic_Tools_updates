local mu = {}
local meshes = table.new(10, 0)
local tiresMaterials = table.new(10, 0)
local impactsMaterials = table.new(10, 0)

local function addMesh(meshName, position, color)
    local rootNode = ac.findNodes('dynamicRoot:yes')
    local mesh = rootNode:loadKN5("assets/" .. meshName .. ".kn5")
    mesh:setPosition(position)
    table.insert(meshes, mesh)
    return mesh
end

---comment
---@param mesh ac.SceneReference
---@param color rgbm
---@return ac.SceneReference
local function configureFlagMesh(mesh, texture, color)
    mesh:applyShaderReplacements(mesh:dumpShaderReplacements(), ac.IncludeType.Track)
    mesh:ensureUniqueMaterials()
    local coloredMesh = mesh:getChildren():findMeshes("flag_000") --   mesh:name():replace("FBX: ", ""):replace(".fbx",""))
    coloredMesh:ensureUniqueMaterials()
    --coloredMesh:setMaterialProperty('ksEmissive', color)
    coloredMesh:setMaterialTexture('txDiffuse', color)
    local imageMesh = mesh:getChildren():findMeshes("tire_0")
    return imageMesh:setMaterialTexture('txDiffuse', texture)
end

local function addTire(carId, position, color)
    local mesh = addMesh("flag_tire", position, color)
    local tireTexture = ac.dirname() .. "/assets/tire.png"
    if false and tiresMaterials[carId] then
        mesh:setMaterialsFrom(tiresMaterials[carId])
    else
        tiresMaterials[carId] = configureFlagMesh(mesh, tireTexture, color)
    end
end

local function addTiresOutsides(carId, count, position, color)
    local mesh = addMesh("flag_tire", position, color)
    local tireTexture = ac.dirname() .. "/assets/tire" .. count .. ".png"
    if false and tiresMaterials[carId] then
        mesh:setMaterialsFrom(tiresMaterials[carId])
    else
        tiresMaterials[carId] = configureFlagMesh(mesh, tireTexture, color)
    end
end

local function addCollision(carId, position, color)
    local mesh = addMesh("flag_tire", position, color)
    local impactTexture = ac.dirname() .. "/assets/impact.png"
    if false and impactsMaterials[carId] then
        mesh:setMaterialsFrom(impactsMaterials[carId])
    else
        impactsMaterials[carId] = configureFlagMesh(mesh, impactTexture, color)
    end
end

function mu:addTires(car, color)
    if car and car.wheels then
        for i = 0, 3, 1 do
            if not car.wheels[i].surfaceValidTrack then
                local position = car.wheels[i].contactPoint
                addTire(car.index, position, color)
            end
        end
        local signPosition = car.position:clone()
        addTiresOutsides(car.index, car.wheelsOutside, signPosition, color)
    end
end

---@param car ac.StateCar
---@param color rgbm
function mu:addCarImpact(car, color)
    if car and car.wheels then
        for i = 0, 3, 1 do
            if car.collisionPosition then
                local position = car.bodyTransform:transformPoint(car.collisionPosition)
                addCollision(car.index, position, color)
            end
        end
    end
end

function mu:clearMeshes()
    for index, mesh in ipairs(meshes) do
        mesh:dispose()
        meshes[index] = nil
    end
end

return mu
