local pu = {}

local paints = table.new(0, 0)

---Get the car TrackPaint object
---@param carIndex integer
---@return ac.TrackPaint
local function getCarPaint(carIndex)
    if not paints[carIndex] then
        paints[carIndex] = ac.TrackPaint()
        paints[carIndex].castStep = math.huge
        paints[carIndex].ageFactor = 0.1
    end
    return paints[carIndex]
end

local contactPointsData = table.new(0, 0)

function pu:resetPaints()
    for i, paint in pairs(paints) do
        if paint then
            paint:reset()
            paint:release()
        end
    end
    paints = table.new(0, 0)
end

local function getCarContactPointsData(carIndex)
    if not contactPointsData[carIndex] then
        local car = ac.getCar(carIndex)
        contactPointsData[carIndex] = {
            lastAngle = 0,
            first = vec3(car.wheels[3].position.x, car.wheels[3].position.y, car.wheels[3].position.z),
            second = vec3(car.wheels[2].position.x, car.wheels[2].position.y, car.wheels[2].position.z),
            lastPosition = car.position:clone()
        }
    end
    return contactPointsData[carIndex]
end

function pu:resetContactPointsData()
    table.clear(contactPointsData)
    --contactPointsData = table.new(0, 0)
end

function pu:resetCarContactPointsData(carIndex)
    local car = ac.getCar(carIndex)
    contactPointsData[carIndex] = {
        lastAngle = 0,
        first = vec3(car.wheels[3].position.x, car.wheels[3].position.y, car.wheels[3].position.z),
        second = vec3(car.wheels[2].position.x, car.wheels[2].position.y, car.wheels[2].position.z),
        lastPosition = car.position:clone()
    }
end

---Update the last contactPointsData for the car
---@param carIndex integer
---@param firstP vec3
---@param secondP vec3
---@param angle number
local function updateCarContactPointsData(carIndex, firstP, secondP, angle)
    local car = ac.getCar(carIndex)
    contactPointsData[carIndex] = {
        first = vec3(firstP.x, firstP.y, firstP.z),
        second = vec3(secondP.x, secondP.y, secondP.z),
        lastAngle = angle,
        lastPosition = car.position:clone()
    }
end

---Draw the contact points for the car
---@param car ac.StateCar
---@param color rgbm
---@param driftAngleWithDirection number
function pu:drawCarContactPoints(car, color, driftAngleWithDirection)
    if car and car.wheels then
        local paint = getCarPaint(car.index)
        local carContactPointsData = getCarContactPointsData(car.index)
        if car.position:distance(carContactPointsData.lastPosition) > math.remap(car.speedKmh, 0, 200, 2, 3) then
            pu:resetCarContactPointsData(car.index)
            carContactPointsData = getCarContactPointsData(car.index)
        end
        local angleWithDirection = driftAngleWithDirection
        -- ac.log(angleWithDirection)
        local first, second
        if angleWithDirection == 0 then
            first = car.wheels[1].position
            second = car.wheels[0].position
            -- elseif angleWithDirection == 90 then
            --     first = car.wheels[3].contactPoint
            --     second = car.wheels[1].contactPoint
            -- elseif angleWithDirection == -90 then
            --     first = car.wheels[0].contactPoint
            --     second = car.wheels[2].contactPoint
        elseif angleWithDirection == 180 or angleWithDirection == -180 then
            first = car.wheels[2].position
            second = car.wheels[3].position
        elseif angleWithDirection > 0 and angleWithDirection < 180 then
            first = car.wheels[3].position
            second = car.wheels[0].position
        elseif angleWithDirection < 0 and angleWithDirection > -180 then
            first = car.wheels[1].position
            second = car.wheels[2].position
            -- elseif angleWithDirection > -180 and angleWithDirection < -90 then
            --     first = car.wheels[0].contactPoint
            --     second = car.wheels[3].contactPoint
            -- elseif angleWithDirection < 180 and angleWithDirection > 90 then
            --     first = car.wheels[2].contactPoint
            --     second = car.wheels[1].contactPoint
        end
        if (angleWithDirection ~= 0 and carContactPointsData.lastAngle ~= 0 and math.sign(carContactPointsData.lastAngle) ~= math.sign(angleWithDirection))
            or angleWithDirection ~= 90 and carContactPointsData.lastAngle ~= 90 and ((carContactPointsData.lastAngle < 90 and angleWithDirection > 90) or (carContactPointsData.lastAngle > 90 and angleWithDirection < 90))
            or angleWithDirection ~= -90 and carContactPointsData.lastAngle ~= -90 and ((carContactPointsData.lastAngle < -90 and angleWithDirection > -90) or (carContactPointsData.lastAngle > -90 and angleWithDirection < -90))
        then
            paint:to(first)
            paint:to(carContactPointsData.first)
            paint:to(second)
            paint:to(carContactPointsData.second)
        else
            paint:to(first)
            paint:to(second)
            paint:to(carContactPointsData.second)
            paint:to(carContactPointsData.first)
        end
        -- paint:fillHint(car.position)
        paint:fill(color)
        -- if (car.index == 0) then
        --     ac.log(string.format("angle %d", angleWithDirection))
        --     ac.log("points ")
        --     ac.log(first)
        --     ac.log(second)
        --     ac.log(carContactPointsData.second)
        --     ac.log(carContactPointsData.first)
        -- end
        if angleWithDirection == 0 then
            updateCarContactPointsData(car.index, car.wheels[3].position, car.wheels[2].position,
                angleWithDirection)
        elseif angleWithDirection == 90 then
            updateCarContactPointsData(car.index, car.wheels[2].position, car.wheels[0].position,
                angleWithDirection)
        elseif angleWithDirection == -90 then
            updateCarContactPointsData(car.index, car.wheels[1].position, car.wheels[3].position,
                angleWithDirection)
        elseif angleWithDirection == 180 or angleWithDirection == -180 then
            updateCarContactPointsData(car.index, car.wheels[0].position, car.wheels[1].position,
                angleWithDirection)
        else
            updateCarContactPointsData(car.index, first, second, angleWithDirection)
        end
    end
end

local redrawJobs = {}

PaintJob = class('PaintJob')
function PaintJob:initialize(index, type, position, color, count)
    ---@public
    self.index = index
    self.type = type
    self.position = position:clone()
    self.color = color
    self.count = count
    self.addedTime = ac.getSim().time
end

PaintJobTypes = {
    TIRE = "Tire",
    TIRES_COUNT = "TiresCount",
    COLLISION = "Collision"
}

local function doTirePaintJob(paint, position,  color)
    paint:image("assets/tire.png", position, vec2(1,1.25), 0, color)
    paint:fill(color)
end

local function addTirePaintJob(index, position,  color)
    local paint = getCarPaint(index)
    table.insert(redrawJobs, PaintJob(index, PaintJobTypes.TIRE, position, color, 0))
    doTirePaintJob(paint, position, color)
end

local function doTiresOutPaintJob(paint, position, color, nbOutside)
    paint:circle(position, 1, false, rgbm.colors.black)
    paint:text("arial", nbOutside, position - vec3(3.6,0,0.3), 10, 0, color)
    paint:fill(color)
end

local function addTiresOutPaintJob(index, position, color, nbOutside)
    local paint = getCarPaint(index)
    table.insert(redrawJobs, PaintJob(index, PaintJobTypes.TIRES_COUNT, position, color, nbOutside))
    doTiresOutPaintJob(paint, position, color, nbOutside)
end

local function doCollisionPaintJob(paint, position, color)
    paint:image("assets/impact.png", position, vec2(1,0.89), 0, color)
    paint:fill(color)
end

local function addCollisionPaintJob(index, position, color)
    local paint = getCarPaint(index)
    table.insert(redrawJobs, PaintJob(index, PaintJobTypes.COLLISION, position, color))
    doCollisionPaintJob(paint, position, color)
end

function pu:redoPaintJobs()
    local toremove = {}
    local acTime = ac.getSim().time
    for index, value in ipairs(redrawJobs) do
        if value.addedTime + 1250 <= acTime then
            local paint = getCarPaint(value.index)
            if (value.type == PaintJobTypes.TIRE) then
                doTirePaintJob(paint, value.position, value.color)
            elseif (value.type == PaintJobTypes.TIRES_COUNT) then
                doTiresOutPaintJob(paint, value.position, value.color, value.count)
            elseif (value.type == PaintJobTypes.COLLISION) then
                doCollisionPaintJob(paint, value.position, value.color)
            end
        end
        if value.addedTime + (value.type == PaintJobTypes.COLLISION and 7000 or 5000) <= acTime then
            table.insert(toremove, index)
        end
    end
    for index, value in ipairs(toremove) do
        table.remove(redrawJobs, value)
    end
end


---Draw the wheels off
---@param car ac.StateCar
---@param color rgbm
function pu:drawCarWheelsOff(car, color)
    if car and car.wheels then
        local paint =  getCarPaint(car.index)
        for i = 0, 3, 1 do
            if not car.wheels[i].surfaceValidTrack then
                local position = car.wheels[i].position  --contactPoint
                addTirePaintJob(paint, position, color)
            end
        end
        local signPosition = car.position:clone():add(vec3(0,5,0))
        addTiresOutPaintJob(paint, signPosition, color, car.wheelsOutside)
    end
end

---Draw the wheels off
---@param car ac.StateCar
---@param color rgbm
function pu:drawCarImpact(car, color)
    if car and car.wheels then
        local paint =  getCarPaint(car.index)
        for i = 0, 3, 1 do
            if car.collisionPosition then
                local position = vec3()
                local quater =  quat.fromAngleAxis((-car.compass + ac.getRealTrackHeadingAngle() - 180) * math.pi/180, vec3(0,1,0))
                local rotatedCollisionPosition = car.collisionPosition:clone()
                rotatedCollisionPosition:rotate(quater)
                position = position:set(car.position):add(rotatedCollisionPosition)
                addCollisionPaintJob(paint, position, color)
            end
        end
    end
end

return pu