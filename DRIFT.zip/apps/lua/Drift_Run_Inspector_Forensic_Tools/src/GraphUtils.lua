---Draws line without any antialiasing the fastest way, good for horizontal or vertical lines.
---@param p1 vec2
---@param p2 vec2
---@param color rgbm
---@param thickness number? @Default value: 1.
---@param spaceSize number? @Default value: 5.
---@return nil
function ui.drawDottedHorizontalLine(p1, p2, color, thickness, spaceSize)
    local x1 = p1.x
    while x1 < p2.x do
        local x2 = math.min(x1 + (spaceSize or 5), p2.x)
        ui.drawSimpleLine(vec2(x1, p1.y), vec2(x2, p1.y), color, thickness or 1)
        x1 = x2 + (spaceSize or 5)
    end
end

function ui.drawGraph(x, y, width, height, data, color, title, minValue, maxValue, drawGraphLines)
    ---@diagnostic disable-next-line: discard-returns
    table.forEach(data, function(value, index)
        if index <= width then
            local pointX = x + width - index
            local pointY = y + height - math.clamp(math.remap(value, minValue, maxValue, 0, height), 0, height)
            ui.pathLineTo(vec2(pointX, pointY))
        end
    end)
    ui.pathStroke(color, false, 2)
    if drawGraphLines then
        ui.drawText(
            string.format("%s (Min: %.2f, Max: %.2f)", title, minValue, maxValue),
            vec2(x + 150, y + 10),
            rgbm.colors.white
        )
        if minValue < 0 then
            ui.drawText(
                "0",
                vec2(x + 5, -16 + y + height - (height * (math.abs(minValue) / (maxValue - minValue)))),
                rgbm.colors.white
            )
            ui.drawDottedHorizontalLine(vec2(x, y + height - (height * (math.abs(minValue) / (maxValue - minValue)))),
                vec2(x + width, y + height - (height * (math.abs(minValue) / (maxValue - minValue)))),
                rgbm.colors.white, 1)
        end

        ui.drawSimpleLine(vec2(x, y + height), vec2(x + width, y + height), rgbm.colors.white, 1)
    end
end

---@param progress number
---@param rectSize vec2
---@param color rgbm
function ui.drawVerticalProgressBar(progress, rectSize, color)
    local startPosition = ui.getCursor()
    if progress == nil then progress = 0 end
    local progressBarFilledSize = vec2(rectSize.x, rectSize.y * progress)

    ui.drawRect(startPosition, startPosition + rectSize, rgbm.colors.gray)
    startPosition.y = startPosition.y + (rectSize.y - progressBarFilledSize.y)
    ui.drawRectFilled(startPosition, startPosition + progressBarFilledSize, color)
    ui.dummy(rectSize + 1)
end
