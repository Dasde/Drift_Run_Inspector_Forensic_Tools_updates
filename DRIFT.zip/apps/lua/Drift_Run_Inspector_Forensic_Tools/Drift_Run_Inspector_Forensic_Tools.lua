---@diagnostic disable: param-type-mismatch
require "src/DataSets"
local pu = require("src.TrackPaintUtils")
local wu = require("src.Wally")
local mu = require("src.MeshUtils")
local uu = require("src.UpdateUtils")

local datas = DataSets()

local toggleProfilingButton = ac.ControlButton('D.R.I.F.T._TOGGLE_PROFILING',
    { keyboard = { key = (ui.KeyIndex.P) } })

local resetProfilingButton = ac.ControlButton('D.R.I.F.T._RESET_PROFILING',
    { keyboard = { key = (ui.KeyIndex.Q) } })

local defaultValues = {
    --   alwaysOpen              = false,
    fontSize                = 62,
    fontColor               = rgbm.colors.lime,
    openDebugWithSettings   = false,
    showNotifications       = true,
    alwaysShowNotifications = false,
    notificationType        = 1,
    drawLines               = true,
    debugMode               = false,
    drawLinesFocusedOnly    = false,
    displayAllDriversCharts = true,
    saveStats               = false,
    statsRecordRootFolder   = ac.getFolder(ac.FolderID.Documents),
    showWally               = true,
    handleCollisions        = false
}

for i, dataSet in ipairs(datas:keySet()) do
    defaultValues[dataSet] = true
end

local DRIFTKey = "D_R_I_F_T_connect_key"
local DRIFTSharedData = {
    ac.StructItem.key(DRIFTKey),
    Connected = ac.StructItem.boolean(),
    Profiling = ac.StructItem.boolean(),
    FocusedDriverName = ac.StructItem.string(128),
    FocusedCarIndex = ac.StructItem.int16(),
    Stats = ac.StructItem.array(ac.StructItem.string(512), 32)
}
StatsConnection = ac.connect(DRIFTSharedData, false, ac.SharedNamespace.Shared)
StatsConnection.Connected = true
StatsConnection.Profiling = false
StatsConnection.Stats = table.new(32, 0)
StatsConnection.FocusedCarIndex = -1
StatsConnection.FocusedDriverName = ""
local AppSettings = ac.storage(defaultValues)
AppSettings.showWally = true -- fix my mistake. remove that later.
local sim = ac.getSim()
local focusedCarDriftAngleWithDirection = 0
local focusedCarDriftAngle = 0
local focusedCarWheelsOutside = 0
local dataUpdateInterval = 0.025 -- Update interval in seconds
-- This is the interval at which the datasets will be updated
local timeSinceLastDataUpdate = 0
local dataSizeLimit = 100
local minSpeed = 2
local selectedDrivers = table.new(0, 0)
local selectedDriversGraphs = table.new(0, 0)
local selectedDriversStats = table.new(0, 0)
local selectedDriversLines = table.new(0, 0)

local collisionHandlerSet = false
local disposeCollisionsHandling ---@type ac.Disposable
local isProfiling = false
-- local isAppRunning = false
local isAppInitialized = false
local statsRecordFilename
local timeSinceLastCollisions = 0

local driversColors = {
    rgbm.colors.blue,
    rgbm.colors.yellow,
    rgbm.colors.red,
    rgbm.colors.green,
    rgbm.colors.fuchsia,
    rgbm.colors.orange,
    rgbm.colors.purple,
    rgbm.colors.cyan,
    rgbm.colors.lime,
    rgbm.colors.teal,
    rgbm.colors.maroon,
    rgbm.colors.silver,
    rgbm.colors.navy,
    rgbm.colors.olive,
    rgbm.colors.aqua,
    rgbm.colors.gray,
}

-- check for update
uu.init("Drift_Run_Inspector_Forensic_Tools",
    "https://raw.githubusercontent.com/Dasde/Drift_Run_Inspector_Forensic_Tools_updates/refs/heads/main/manifest.ini",
    "https://github.com/Dasde/Drift_Run_Inspector_Forensic_Tools_updates/raw/refs/heads/main/DRIFT.zip")
uu.checkForUpdate()

---Get a different color for each car index
---@param index integer
---@return rgbm
local function getDriverColor(index)
    if not driversColors[index + 1] then
        driversColors[index + 1] = rgbm.new(
            math.random(),
            math.random(),
            math.random(),
            1
        ) -- Generate a random color if the index exceeds the predefined colors
    end
    return driversColors[index + 1]
end

local function calculateDriftAngle(car)
    local driftAngle = 0
    local driftAngleWithDirection = 0
    if car and car.speedKmh and car.speedKmh > 20 then
        local velocityX = car.velocity.x
        local velocityZ = car.velocity.z
        local velocityDirection = math.atan2(velocityZ, velocityX)
        local carHeading = math.atan2(car.look.z, car.look.x)
        driftAngle = velocityDirection - carHeading
        if driftAngle > math.pi then
            driftAngle = driftAngle - 2 * math.pi
        elseif driftAngle < -math.pi then
            driftAngle = driftAngle + 2 * math.pi
        end
        driftAngleWithDirection = math.deg(driftAngle)
        driftAngle = math.abs(math.deg(driftAngle))
    end
    return driftAngle, driftAngleWithDirection
end

local dataSetsList
local function initDataSetList()
    if dataSetsList then
        table.clear(dataSetsList)
    else
        dataSetsList = {}
    end
    for i, dataSet in ipairs(datas:keySet()) do
        if AppSettings[dataSet] then
            table.insert(dataSetsList, dataSet)
        end
    end
end

---Handle wheels outside events
---@param car ac.StateCar
---@param lastWheelsOustide integer
---@param drawCarWheelsOff boolean
---@param showNotifications boolean
---@return integer
local function onWheelOutside(car, lastWheelsOustide, drawCarWheelsOff, showNotifications)
    if car.wheelsOutside > 0 then
        if not lastWheelsOustide or lastWheelsOustide < car.wheelsOutside then
            if drawCarWheelsOff then
                --pu:drawCarWheelsOff(car, getDriverColor(car.index))
                mu:addTires(car, getDriverColor(car.index))
            end
            if showNotifications then
                if (AppSettings.notificationType == 2) then
                    ui.toast("icons/Tires.png", car:driverName() .. " Wheels outside " .. car.wheelsOutside .. ".")
                else
                    ac.setMessage(car:driverName() .. " Wheels outside", car.wheelsOutside)
                end
            end
        end
        lastWheelsOustide = math.max(
            (not lastWheelsOustide) and 0 or lastWheelsOustide,
            car.wheelsOutside)
    else
        lastWheelsOustide = 0
    end
    return lastWheelsOustide
end

local function displayCollideWithCarNotification(car, collidedWith)
    if AppSettings.showNotifications then
        if (AppSettings.notificationType == 2) then
            if collidedWith == 0 then
                ui.toast("icons/Crash Wall.png", car:driverName() .. " Collision with the track.")
            else
                ui.toast("icons/Crash Car.png", car:driverName() .. " Collision with " .. ac.getCar(collidedWith - 1):driverName() .. ".")
            end
        else
            if collidedWith == 0 then
                ac.setMessage(car:driverName() .. " Collision with", "track")
            else
                ac.setMessage(car:driverName() .. " Collision with", ac.getCar(collidedWith - 1):driverName())
            end
        end
    end
end

local function drawCarImpact(car)
    if AppSettings.drawLines then
        pu:drawCarImpact(car, getDriverColor(car.index))
        mu:addCarImpact(car, getDriverColor(car.index))
    end
end

local onCarCollision = function(carIndex)
    if (isProfiling) or AppSettings.alwaysShowNotifications then
        if not datas.stats[carIndex] then
            datas.stats[carIndex] = Stats()
        end
        local car = ac.getCar(carIndex)
        local collidedWith = car.collidedWith
        if collidedWith == 0 then
            if ac.getSim().isOnlineRace then
                for i, c in ac.iterateCars.ordered() do
                    if c.index ~= carIndex and car.position:distance(c.position) < 10 and ac.areCarsColliding(c.index, carIndex) then
                        collidedWith = c.index + 1
                        goto withcar
                    end
                end
            end
            datas.stats[carIndex].lastCollisionsWithWalls = 1
            datas.stats[carIndex].collisionsWithWalls = datas.stats[carIndex].collisionsWithWalls + 1
            ::withcar::
        end
        if collidedWith > 0 then
            datas.stats[carIndex].lastCollisionsWithCars = 1
            datas.stats[carIndex].collisionsWithCars = datas.stats[carIndex].collisionsWithCars + 1
            datas.stats[carIndex].lastCollisionWith = ac.getCar(collidedWith - 1):driverName()
        end
        displayCollideWithCarNotification(car, collidedWith)
        drawCarImpact(car)
        datas.stats[carIndex].collisions = datas.stats[carIndex].collisions + 1
        datas.stats[carIndex].lastCollision = 1
    end
end

local drawUpdateInterval = 0.025 -- Update interval in seconds
-- This is the interval at which the datasets will be updated
local timeSinceLastDrawUpdate = 0

local function startProfiling()
    local folder = AppSettings.statsRecordRootFolder .. "/DRIFT Stats"
    if not io.fileExists(folder) then
        io.createDir(folder)
    end
    statsRecordFilename = folder ..
        "/" .. ac.getTrackName() .. "_###_" .. string.format("%s", ac.getSim().timestamp) .. ".json"
    if AppSettings.showWally then
        for i, car in ac.iterateCars.ordered() do
            wu:displayWally(car)
        end
    end
end

local function stopProfiling()
    if AppSettings.showWally then
        for i, car in ac.iterateCars.ordered() do
            wu:removeWally(car)
        end
    end
end

local function toggleProfiling()
    isProfiling = not isProfiling
    StatsConnection.Profiling = isProfiling
    if isProfiling then
        startProfiling()
    else
        stopProfiling()
    end
end

local function resetProfiling()
    for i, c in ac.iterateCars.ordered() do
        datas:resetStats(c.index)
    end
    StatsConnection.Stats = {}
    pu:resetPaints()
    pu:resetContactPointsData()
    mu:clearMeshes()
end

function script.windowMainOnShow()
    -- isAppRunning = true
    if not isAppInitialized then initDataSetList() end
    isAppInitialized = true
    if not collisionHandlerSet and AppSettings.handleCollisions then
        disposeCollisionsHandling = ac.onCarCollision(-1, onCarCollision)
        collisionHandlerSet = true
    end
end

function script.windowMainOnHide()
    -- isAppRunning = false
    if not isProfiling then
        pu:resetPaints()
        pu:resetContactPointsData()
        mu:clearMeshes()
    end
end

local lastReplayFrame = 0
function script.Draw3D(dt)
    if isProfiling and AppSettings.drawLines then
        if ac.getGameDeltaT() > 0 then
            timeSinceLastDrawUpdate = timeSinceLastDrawUpdate + dt
            if timeSinceLastDrawUpdate < drawUpdateInterval then
                return
            end
            timeSinceLastDrawUpdate = 0
            if sim.isReplayActive then
                if lastReplayFrame > sim.replayCurrentFrame or (lastReplayFrame + (1 * sim.replayPlaybackRate) + 3) < sim.replayCurrentFrame then
                    -- ac.log("replay frame skipped")
                    pu:resetContactPointsData()
                    pu:resetPaints()
                    mu:clearMeshes()
                end
                lastReplayFrame = sim.replayCurrentFrame
            end
            local focusedCar = ac.getCar(sim.focusedCar)
            if not AppSettings.drawLinesFocusedOnly then
                for i, car in ac.iterateCars.ordered(true) do
                    local selected = (table.contains(selectedDrivers, car.index) and table.contains(selectedDriversLines, car.index))
                    if selected then
                        if car and car.index ~= sim.focusedCar and car.speedKmh > minSpeed then
                            pu:drawCarContactPoints(car, getDriverColor(car.index),
                                datas.driftAngleWithDirection:getLastValue(car.index) or 0)
                        elseif car.speedKmh <= 30 then
                            pu:resetCarContactPointsData(car.index)
                        end
                    end
                end
            end
            if focusedCar and focusedCar.speedKmh > minSpeed then
                pu:drawCarContactPoints(focusedCar, getDriverColor(focusedCar.index),
                    datas.driftAngleWithDirection:getLastValue(focusedCar.index) or 0)
            end
            pu:redoPaintJobs()
        end
    end
end

function script.update(dt)
    local focusedCarIndex = sim.focusedCar ~= -1 and sim.focusedCar or 0

    if toggleProfilingButton:pressed() then
        toggleProfiling()
    end

    if resetProfilingButton:pressed() then
        resetProfiling()
    end

    if ac.getGameDeltaT() > 0 then
        if isProfiling then
            timeSinceLastDataUpdate = timeSinceLastDataUpdate + dt
            if timeSinceLastDataUpdate < dataUpdateInterval then
                return
            end
            timeSinceLastDataUpdate = 0
            if (not collisionHandlerSet) and AppSettings.handleCollisions then
                disposeCollisionsHandling = ac.onCarCollision(-1, onCarCollision)
                collisionHandlerSet = true
            end
            for i, car in ac.iterateCars.ordered() do
                local angle, angleWithDirection = calculateDriftAngle(car)
                local speed = car.speedKmh
                local name = car:driverName()
                local diff = car.drivetrainSpeed - car.speedKmh
                datas.driftAngle:addValue(math.floor(angle), car.index, dataSizeLimit, AppSettings.debugMode)
                datas.driftAngleWithDirection:addValue(math.floor(angleWithDirection), car.index, dataSizeLimit,
                    AppSettings.debugMode)
                datas.speed:addValue(speed, car.index, dataSizeLimit, AppSettings.debugMode)
                datas.speedDiff:addValue(diff, car.index, dataSizeLimit, AppSettings.debugMode)
                datas.gforces:addValue(car.acceleration.z, car.index, dataSizeLimit, AppSettings.debugMode)
                datas.throttle:addValue(car.gas, car.index, dataSizeLimit, AppSettings.debugMode)
                datas.clutch:addValue(1 - car.clutch, car.index, dataSizeLimit, AppSettings.debugMode)
                datas.brake:addValue(car.brake, car.index, dataSizeLimit, AppSettings.debugMode)
                datas.handbrake:addValue(math.clamp(car.handbrake, 0, 1), car.index, dataSizeLimit, AppSettings
                    .debugMode)
                datas.gear:addValue(car.gear, car.index, dataSizeLimit, AppSettings.debugMode)
                datas.stats[car.index] = datas.stats[car.index] or Stats()
                datas.stats[car.index].lastWheelsOustide = onWheelOutside(car, datas.stats[car.index].lastWheelsOustide,
                    AppSettings.drawLines and
                    ((AppSettings.drawLinesFocusedOnly and car.index == focusedCarIndex) or (not AppSettings.drawLinesFocusedOnly)) or
                    false, AppSettings.showNotifications)
                datas.stats[car.index].wheelsOustide = math.max(datas.stats[car.index].wheelsOustide, car.wheelsOutside)
                if not collisionHandlerSet then
                    if car.collidedWith > -1 then
                        if dt + timeSinceLastCollisions > 0.25 then
                            datas.stats[car.index].collisions = datas.stats[car.index].collisions + 1
                            datas.stats[car.index].lastCollision = 1
                            timeSinceLastCollisions = 0
                            if car.collidedWith == 0 then
                                datas.stats[car.index].collisionsWithWalls = datas.stats[car.index].collisionsWithWalls +
                                1
                                datas.stats[car.index].lastCollisionsWithWalls = 1
                            else
                                datas.stats[car.index].lastCollisionsWithCarscollisionsWithCars = 1
                                datas.stats[car.index].collisionsWithCars = datas.stats[car.index].collisionsWithCars + 1
                                datas.stats[car.index].lastCollisionWith = ac.getDriverName(car.collidedWith - 1)
                            end
                            displayCollideWithCarNotification(car, car.collidedWith)
                            drawCarImpact(car)
                        else
                            timeSinceLastCollisions = timeSinceLastCollisions + dt
                        end
                    else
                        timeSinceLastCollisions = timeSinceLastCollisions + dt
                        datas.stats[car.index].lastCollision = 0
                        datas.stats[car.index].lastCollisionsWithWalls = 0
                        datas.stats[car.index].lastCollisionWith = -1
                    end
                end
                if car.isInPit or car.isInPitlane then
                    pu:resetCarContactPointsData(car.index)
                end
                if car.index == focusedCarIndex then
                    focusedCarDriftAngle = angle
                    focusedCarDriftAngleWithDirection = angleWithDirection
                    if (AppSettings.debugMode) then
                        ac.debug("-Focused driver- ", car:driverName())
                    end
                end
                if AppSettings.saveStats then
                    datas:saveStats(car.index, statsRecordFilename)
                end
                StatsConnection.Stats[car.index] = datas:exportStats(car.index)
                datas:resetCollisionsStats(car.index)
            end
        else
            local car = ac.getCar(focusedCarIndex)
            focusedCarDriftAngle, focusedCarDriftAngleWithDirection = calculateDriftAngle(car)
            if (AppSettings.debugMode) then
                ac.debug("-Focused driver- ", car:driverName())
            end
            if AppSettings.alwaysShowNotifications then
                focusedCarWheelsOutside = onWheelOutside(car, focusedCarWheelsOutside, false, true)
                if (not collisionHandlerSet) and AppSettings.handleCollisions then
                    disposeCollisionsHandling = ac.onCarCollision(-1, onCarCollision)
                    collisionHandlerSet = true
                end
            end
        end
    else
        -- If the game delta time is not greater than 0, we assume the game is paused or not running
        if (AppSettings.debugMode) then
            local car = ac.getCar(focusedCarIndex)
            ac.debug("-Focused driver- ", car:driverName())
        end
    end
    if StatsConnection.FocusedCarIndex ~= focusedCarIndex then
        StatsConnection.FocusedCarIndex = focusedCarIndex
        StatsConnection.FocusedDriverName = ac.getCar(focusedCarIndex):driverName()
    end
    --   end
end

function script.windowMain(dt)
    local buttonSize = vec2(180, 75)
    local buttonIconSize = vec2(24, 24)
    local buttonIconOffset = vec2(10, 24)

    ---draw a settings button
    ---@param name string
    local function settingsButton(name)
        local normalizedName = name:lower():replace(" ", "_")
        if ac.isWindowOpen(normalizedName) then
            if ui.button("Close " .. name, buttonSize) then
                ac.setAppWindowVisible(normalizedName, "?", false)
                ac.setWindowOpen(normalizedName, false)
            end
        else
            if ui.button("Open " .. name, buttonSize) then
                ac.setAppWindowVisible(normalizedName)
                ac.setWindowOpen(normalizedName, true)
            end
        end
        ui.addIcon("icons/" .. normalizedName .. ".png", buttonIconSize, ui.Alignment.Center, nil, buttonIconOffset)
    end
    ui.pushFont(ui.Font.Title)
    ui.header("Drift Run Inspector Forensic Tools ")
    ui.popFont()
    ui.columns(2, false, "menuColumns")
    ui.setColumnWidth(0, 200)

    settingsButton("Drivers")
    settingsButton("Drift Angle")
    settingsButton("Graphs")
    if AppSettings.drawLines then
        if ui.button("Stop Lines", buttonSize) then
            AppSettings.drawLines = false
            pu:resetContactPointsData()
        end
    else
        if ui.button("Trace Lines", buttonSize) then
            AppSettings.drawLines = true
        end
    end
    ui.addIcon("icons/driving_line.png", buttonIconSize, ui.Alignment.Center, nil, buttonIconOffset)
    settingsButton("Stats")
    settingsButton("Settings")
    ui.nextColumn()
    ui.setColumnWidth(1, 200)
    ui.pushFont(ui.Font.Title)
    if isProfiling then
        ui.textAligned("  Stop Inspecting", ui.Alignment.Center, vec2(200, 25))
    else
        ui.textAligned("  Start Inspecting", ui.Alignment.Center, vec2(200, 25))
    end
    if ui.iconButton(isProfiling and "icons/stop inspecting.png" or "icons/Start inspecting.png", vec2(150, 150), 25, true, isProfiling and ui.ButtonFlags.Active or ui.ButtonFlags.None) then
        toggleProfiling()
    end

    ui.setCursorY(ui.getCursorY() + 28)

    ui.textAligned("   Reset Profiling", ui.Alignment.Center, vec2(200, 25))
    ui.popFont()
    if ui.iconButton("icons/reset.png", vec2(150, 150), nil, nil, 25) then
        resetProfiling()
    end
end

function script.windowAngle(dt)
    ui.pushFont(ui.Font.Title)
    ui.header("Drift Angle")
    ui.popFont()
    ui.setNextTextBold()
    ui.pushDWriteFont()
    ui.dwriteText(math.floor(focusedCarDriftAngle) .. "°", AppSettings.fontSize, AppSettings.fontColor)
    ui.popDWriteFont()
end

function script.drawGraphs()
    if not dataSetsList then
        initDataSetList()
    end
    local focusedCarIndex = sim.focusedCar ~= -1 and sim.focusedCar or 0
    local xOffset = 160
    local yOffset = 20
    local graphWidth = ui.windowWidth() - xOffset
    local graphHeight = (ui.windowHeight() - yOffset) / #dataSetsList
    dataSizeLimit = graphWidth
    for i, c in ac.iterateCars.ordered() do
        -- ui.drawDriverIcon(c.index, vec2(100, 50))
        local name = c:driverName()
        local driverColor = getDriverColor(c.index)
        ui.dwriteText(name, 13, driverColor)
        local cursorY = ui.getCursorY()
        local focused = c.index == focusedCarIndex
        if ui.radioButton("Focus###" .. name, focused) then
            if not focused then
                ac.focusCar(c.index)
            end
        end

        ui.setCursor(vec2(90, cursorY))
        local selected = AppSettings.displayAllDriversCharts or
            (table.contains(selectedDrivers, c.index) and table.contains(selectedDriversGraphs, c.index)) or
            focusedCarIndex == c.index
        if ui.checkbox("Show ##" .. name, selected) then
            selected = not selected
            if selected then
                if not table.contains(selectedDriversGraphs, c.index) then
                    table.insert(selectedDriversGraphs, c.index)
                end
            else
                if table.contains(selectedDriversGraphs, c.index) then
                    table.remove(selectedDriversGraphs, table.indexOf(selectedDriversGraphs, c.index))
                end
            end
        end
        if (selected or focused) then
            datas:drawGraphs(xOffset, yOffset, graphWidth, graphHeight, c.index, driverColor, focused, dataSetsList)
        end
    end
end

function script.windowStats()
    local function drawInputs(car, inputWidth, inputHeight)
        local cursor = ui.getCursor()
        cursor.x = cursor.x + 200
        ui.setCursor(vec2(cursor.x, cursor.y))
        ui.drawVerticalProgressBar(1 - car.clutch, vec2(inputWidth, inputHeight), rgbm.colors.blue)
        ui.drawText("C", vec2(cursor.x + 5, cursor.y - 10 + inputHeight / 2), rgbm.colors.white)
        cursor.x = cursor.x + (inputWidth * 2)
        ui.setCursor(vec2(cursor.x, cursor.y))
        ui.drawVerticalProgressBar(car.brake, vec2(inputWidth, inputHeight), rgbm.colors.red)
        ui.drawText("B", vec2(cursor.x + 5, cursor.y - 10 + inputHeight / 2), rgbm.colors.white)
        cursor.x = cursor.x + (inputWidth * 2)
        ui.setCursor(vec2(cursor.x, cursor.y))
        ui.drawVerticalProgressBar(car.gas, vec2(inputWidth, inputHeight), rgbm.colors.green)
        ui.drawText("T", vec2(cursor.x + 5, cursor.y - 10 + inputHeight / 2), rgbm.colors.white)
        cursor.x = cursor.x + (inputWidth * 2)
        ui.setCursor(vec2(cursor.x, cursor.y))
        ui.drawVerticalProgressBar(math.clamp(car.handbrake, 0, 1), vec2(inputWidth, inputHeight), rgbm.colors.yellow)
        ui.drawText("H", vec2(cursor.x + 5, cursor.y - 10 + inputHeight / 2), rgbm.colors.white)
    end
    local function drawGMeters(car, gmeterWidth, gmeterHeight)
        local cursor = ui.getCursor()
        cursor.x = cursor.x + 200
        ui.setCursor(vec2(cursor.x, cursor.y))
        ui.drawVerticalProgressBar(math.remap(math.clamp(car.acceleration.z, 0, 5), 0, 5, 0, 1),
            vec2(gmeterWidth, gmeterHeight / 2), rgbm.colors.green)
        ui.setCursor(vec2(cursor.x, cursor.y))
        ui.drawVerticalProgressBar(math.remap(math.clamp(car.acceleration.z, -5, 0), -5, 0, -1, 0),
            vec2(gmeterWidth, gmeterHeight / 2), rgbm.colors.red)
        ui.setCursor(vec2(cursor.x, cursor.y + gmeterHeight / 2))
        ui.drawRect(ui.getCursor(), ui.getCursor() + vec2(gmeterWidth, gmeterHeight / 2), rgbm.colors.gray)
        ui.drawText("G-METER", vec2(cursor.x + 45, cursor.y - 8 + gmeterHeight / 2), rgbm.colors.white)
    end

    local cursor = nil
    if ui.button("Reset Stats") then
        for i, c in ac.iterateCars.ordered() do
            datas:resetStats(c.index)
        end
    end
    local focusedCarIndex = sim.focusedCar ~= -1 and sim.focusedCar or 0
    for i, c in ac.iterateCars.ordered() do
        local selected = (table.contains(selectedDrivers, c.index) and table.contains(selectedDriversStats, c.index)) or
        focusedCarIndex == c.index
        if selected then
            local name = c:driverName()
            local driverColor = getDriverColor(c.index)
            ui.dwriteText(name, 13, driverColor)
            ui.separator()
            cursor = ui.getCursor()
            ui.setCursor(vec2(cursor.x + 200, cursor.y))
            drawInputs(c, 20, 100)
            ui.setCursor(vec2(cursor.x + 200, cursor.y + 120))
            drawGMeters(c, 140, 100)
            ui.setCursor(cursor)
            if (datas.stats[c.index] == nil) then
                datas.stats[c.index] = Stats()
            end
            ui.dwriteText("Collisions: " .. datas.stats[c.index].collisions, c.collidedWith >= 0 and 20 or 13,
                c.collidedWith >= 0 and rgbm.colors.red or rgbm.colors.white)
            ui.dwriteText("Collisions with walls: " .. datas.stats[c.index].collisionsWithWalls,
                c.collidedWith == 0 and 20 or 13, c.collidedWith == 0 and rgbm.colors.red or rgbm.colors.white)
            ui.dwriteText("Collisions with cars: " .. datas.stats[c.index].collisionsWithCars,
                c.collidedWith > 0 and 20 or 13, c.collidedWith > 0 and rgbm.colors.red or rgbm.colors.white)
            ui.dwriteText("Wheels outside: " .. datas.stats[c.index].wheelsOustide .. '(' .. c.wheelsOutside .. ')',
                c.wheelsOutside > 0 and 20 or 13, c.wheelsOutside > 0 and rgbm.colors.red or rgbm.colors.white)
            ui.dwriteText(datas:displayStats(c.index), 13, rgbm.colors.white)
            if c.collidedWith == 0 then
                ui.drawIcon("icons/Crash Wall.png", vec2(cursor.x + 230, cursor.y + 20),
                    vec2(cursor.x + 310, cursor.y + 100))
            else
                if c.collidedWith > 0 then
                    ui.drawIcon("icons/Crash Car.png", vec2(cursor.x + 230, cursor.y + 20),
                        vec2(cursor.x + 310, cursor.y + 100))
                end
            end
            if c.wheelsOutside > 0 then
                ui.drawIcon("icons/Tires.png", vec2(cursor.x + 230, cursor.y + 120), vec2(cursor.x + 310, cursor.y + 200))
                ui.setNextTextBold()
                ui.dwriteDrawText(string.format("%s", c.wheelsOutside), 45, vec2(cursor.x + 257, cursor.y + 125),
                    rgbm.colors.white)
            end
        end
    end
end

function script.windowLines()
    if ui.checkbox("Toggle Lines", AppSettings.drawLines) then
        AppSettings.drawLines = not AppSettings.drawLines
    end

    if ui.checkbox("Only display lines for focused car", AppSettings.drawLines) then
        AppSettings.drawLinesFocusedOnly = not AppSettings.drawLinesFocusedOnly
    end

    if ui.button("Reset Lines") then
        pu:resetPaints()
        pu:resetContactPointsData()
        mu:clearMeshes()
    end
end

function script.windowDrivers()
    local cursor = nil
    local focusedCarIndex = sim.focusedCar ~= -1 and sim.focusedCar or 0

    ---Update the options of the driver
    ---@param car ac.StateCar
    ---@param selected boolean
    ---@param optionDriversList table    
    ---@param subOptionsDriverLists table
    local function updateDriverOptions(car, selected, optionDriversList, subOptionsDriverLists)
        if selected then
            if not table.contains(optionDriversList, car.index) then
                table.insert(optionDriversList, car.index)
            end
            if subOptionsDriverLists then
                for index, list in ipairs(subOptionsDriverLists) do
                    if not table.contains(list, car.index) then
                        table.insert(list, car.index)
                    end
                end
            end
        else
            if table.contains(optionDriversList, car.index) then
                table.remove(optionDriversList, table.indexOf(optionDriversList, car.index))
            end
        end
    end

    ---Display a show/hide check box for an option
    ---@param car ac.StateCar
    ---@param optionName string
    ---@param condition boolean
    ---@param optionDriversList table
    ---@param subOptionsDriverLists table
    ---@return boolean
    local function showDriverOption(car, optionName, condition, optionDriversList, subOptionsDriverLists)
        local selected = condition or table.contains(optionDriversList, car.index) or
            focusedCarIndex == car.index
        if ui.checkbox("Show " .. optionName .. "##" .. car:driverName(), selected) then
            selected = not selected
            updateDriverOptions(car, selected, optionDriversList, subOptionsDriverLists)
        end
        return selected
    end
    if ui.checkbox("Only display lines for focused car", AppSettings.drawLinesFocusedOnly) then
        AppSettings.drawLinesFocusedOnly = not AppSettings.drawLinesFocusedOnly
    end
    if ui.checkbox("Display charts for all drivers", AppSettings.displayAllDriversCharts) then
        AppSettings.displayAllDriversCharts = not AppSettings.displayAllDriversCharts
    end
    local previouslySelected
    for i, c in ac.iterateCars.ordered() do
        -- ui.drawDriverIcon(c.index, vec2(100, 50))
        local name = c:driverName()
        local driverColor = getDriverColor(c.index)
        ui.dwriteText(name, 13, driverColor)
        ui.separator()
        cursor = ui.getCursor()
        ui.setCursor(vec2(20, cursor.y))
        local cursorY = ui.getCursorY()
        local focused = c.index == focusedCarIndex
        if focused then
            updateDriverOptions(c, true, selectedDrivers, { selectedDriversGraphs, selectedDriversLines, selectedDriversStats })
        end
        if ui.radioButton("Focus###" .. name, focused) then
            if not focused then
                ac.focusCar(c.index)
                updateDriverOptions(c, true, selectedDrivers, { selectedDriversGraphs, selectedDriversLines, selectedDriversStats })
            end
        end

        ui.setCursor(vec2(90, cursorY))
        local selected = showDriverOption(c, "", false, selectedDrivers,
            { selectedDriversGraphs, selectedDriversLines, selectedDriversStats })
        if selected then
            ui.setCursor(vec2(190, cursorY))
            showDriverOption(c, "Graphs", AppSettings.displayAllDriversCharts, selectedDriversGraphs,{})

            ui.setCursor(vec2(300, cursorY))
            local condition = AppSettings.drawLinesFocusedOnly and c.index == focusedCarIndex
            showDriverOption(c, "Lines", condition, selectedDriversLines,{})

            ui.setCursor(vec2(400, cursorY))
            showDriverOption(c, "Stats", false, selectedDriversStats,{})
        end
    end
end

function script.windowSettings()
    ui.tabBar("settingsTabBar", function()
        ui.tabItem("General", function()
            ui.pushFont(ui.Font.Title)
            ui.text("Debug")
            ui.popFont()
            if ui.checkbox("Log in Lua Debug", AppSettings.debugMode) then
                AppSettings.debugMode = not AppSettings.debugMode
            end

            ui.pushFont(ui.Font.Title)
            ui.text("Collisions and wheels outside")
            ui.popFont()
            ui.text(
            "Collisions detection is deactivate by default, there are issues with current version of CSP (0.2.11), it does not work in replays")
            if ui.checkbox("Handle Collisions (experimental, only works online)", AppSettings.handleCollisions) then
                AppSettings.handleCollisions = not AppSettings.handleCollisions
                if AppSettings.handleCollisions then
                    if not collisionHandlerSet then
                        disposeCollisionsHandling = ac.onCarCollision(-1, onCarCollision)
                        collisionHandlerSet = true
                    end
                else
                    if collisionHandlerSet then
                        disposeCollisionsHandling()
                        collisionHandlerSet = false
                    end
                end
            end
            if ui.checkbox("Toggle Notifications", AppSettings.showNotifications) then
                AppSettings.showNotifications = not AppSettings.showNotifications
            end
            if AppSettings.showNotifications then
                if ui.checkbox("Always Show Notifications", AppSettings.alwaysShowNotifications) then
                    AppSettings.alwaysShowNotifications = not AppSettings.alwaysShowNotifications
                end
            else
                AppSettings.alwaysShowNotifications = false
            end

            ui.pushFont(ui.Font.Title)
            ui.text("Notification type")
            ui.popFont()

            if ui.radioButton("Use message on top", AppSettings.notificationType == 1) then
                AppSettings.notificationType = 2
            end
            if ui.radioButton("Use toast notification", AppSettings.notificationType == 2) then
                AppSettings.notificationType = 1
            end

            ui.pushFont(ui.Font.Title)
            ui.text("Save stats on disk")
            ui.popFont()
            if ui.checkbox("Save stats as json files", AppSettings.saveStats) then
                AppSettings.saveStats = not AppSettings.saveStats
            end
            ui.pushFont(ui.Font.Title)
            ui.text("Current Stats root folder :")
            ui.popFont()
            ui.text(AppSettings.statsRecordRootFolder)
            if ui.button("Open Stats save folder") then
                local folder = AppSettings.statsRecordRootFolder .. "/DRIFT Stats"
                if not io.fileExists(folder) then
                    io.createDir(folder)
                end
                os.openInExplorer(folder)
            end
            if ui.button("Change Stats root folder") then
                os.openFileDialog({
                    defaultFolder = AppSettings.statsRecordRootFolder,
                    flags = os.DialogFlags
                        .PickFolders
                }, function(err, filename)
                    if not err and filename then
                        AppSettings.statsRecordRootFolder = filename
                    end
                end)
            end
        end)
        ui.tabItem("Drift Angle", function()
            ui.pushFont(ui.Font.Title)
            ui.text("Focused Car Drift Angle")
            ui.popFont()
            ui.setNextTextBold()
            ui.text("Font Size")
            AppSettings.fontSize = ui.slider("Font Size", AppSettings.fontSize, 20, 200)

            ui.setNextTextBold()
            ui.text("Font Color")
            if ui.colorPicker("Font Color", AppSettings.fontColor) then
                AppSettings.fontColor = AppSettings.fontColor
            end
        end)
        ui.tabItem("Graphs", function()
            ui.pushFont(ui.Font.Title)
            ui.text("Graphs")
            ui.popFont()
            ui.setNextTextBold()
            ui.text("Display all drivers")
            if ui.checkbox("Display all drivers", AppSettings.displayAllDriversCharts) then
                AppSettings.displayAllDriversCharts = not AppSettings.displayAllDriversCharts
            end
            ui.setNextTextBold()
            ui.text("Select Data Sets")
            for i, dataSet in ipairs(datas:keySet()) do
                local dataSetTitle = datas[dataSet].title
                if ui.checkbox(dataSetTitle, AppSettings[dataSet] or false) then
                    AppSettings[dataSet] = not AppSettings[dataSet]
                    initDataSetList()
                end
            end
        end)
        ui.tabItem("Lines", function()
            ui.pushFont(ui.Font.Title)
            ui.text("Draw Car Lines")
            ui.popFont()
            if ui.checkbox("Toggle Lines", AppSettings.drawLines) then
                AppSettings.drawLines = not AppSettings.drawLines
            end
            if ui.checkbox("Only display lines for focused car", AppSettings.drawLinesFocusedOnly) then
                AppSettings.drawLinesFocusedOnly = not AppSettings.drawLinesFocusedOnly
            end
        end)
        ui.tabItem("Controls", function()
            ui.pushFont(ui.Font.Title)
            ui.text("Control the profiler")
            ui.popFont()
            ui.setNextTextBold()
            ui.text("How to toggle the profiling on and off")
            ui.text("Press " .. toggleProfilingButton:boundTo() .. " to toggle the profiling")
            ui.setNextTextBold()
            ui.text("How to clear the profiling")
            ui.text("Press " .. resetProfilingButton:boundTo() .. " to clear the profiling (traces, stats...)")
            ui.setNextTextBold()
            ui.text("You can change the controls with the Extended Controls app")
            if ui.button("Open Extended Controls") then
                ac.setAppOpen("ext_controls")
                ac.setAppWindowVisible("ext_controls")
            end
        end)
        ui.tabItem("Update", function()
            ui.pushFont(ui.Font.Title)
            ui.text("Update")
            ui.popFont()
            uu.drawUI()
        end)
    end)
end
