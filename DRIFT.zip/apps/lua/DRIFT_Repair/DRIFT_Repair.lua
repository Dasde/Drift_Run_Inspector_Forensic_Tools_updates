-- Rewrites D.R.I.F.T.'s script when an update left it behind: the old `crucial` updater
-- extracts everything but the running script, which then fails its integrity check.

local TARGET_VERSION = const('1.3.20')
local TARGET_SHA = const('cfa715eb24bd29c10244518950bb1caa07592aeebecb24c3214b3fff4ef4e0ab')
local DRIFT_DIR = ac.getFolder(ac.FolderID.ACAppsLua) .. '/Drift_Run_Inspector_Forensic_Tools'
local SCRIPT = DRIFT_DIR .. '/Drift_Run_Inspector_Forensic_Tools.lua'

local status = 'waiting'
local done = false

local function repair()
	local version = ac.INIConfig.load(DRIFT_DIR .. '/manifest.ini', ac.INIFormat.Extended)
		:get('ABOUT', 'VERSION', '0.0.0')
	-- Only the release this payload belongs to: a newer D.R.I.F.T. must never be rolled back.
	if version ~= TARGET_VERSION then
		status = 'D.R.I.F.T. ' .. version .. ', nothing to do'
		return
	end
	local current = io.load(SCRIPT)
	if current and ac.checksumSHA256(current) == TARGET_SHA then
		status = 'D.R.I.F.T. ' .. version .. ' is intact'
		return
	end
	local payload = io.load(ac.dirname() .. '/payload.zip')
	if not payload then
		status = 'payload missing'
		return
	end
	status = 'repairing'
	io.extractFromZipAsync(payload, ac.getFolder(ac.FolderID.Root), nil, function(err)
		status = err and ('repair failed: ' .. tostring(err)) or 'D.R.I.F.T. repaired'
		ac.log('[DRIFT_Repair] ' .. status)
	end)
end

function script.update()
	if done then return end
	done = true
	repair()
	ac.log('[DRIFT_Repair] ' .. status)
end

function script.windowMain()
	ui.text(status)
end
